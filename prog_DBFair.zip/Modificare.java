import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Modificare {

	private JFrame frame;
	private JTextField textCodice;
	private JTextField textNome;
	private JTextField textCognome;
	private JTextField textTipo;
	private JTextField textOpere;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Modificare window = new Modificare();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Modificare() {
		initialize();
		this.frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(64, 224, 208));
		frame.setBounds(100, 100, 494, 352);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton modifica = new JButton("Modifica"); // le variabili le devo cambiare tutte con minuscolo
		modifica.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Operazioni con=new Operazioni();// diachiaro una nuova variabile per effetuare l'operazione
				String codiceInserito=textCodice.getText();
				String nomeInserito=textNome.getText(); // parametri
				String cognomeInserito=textCognome.getText();
				String tipoInserito=textTipo.getText();
				String opereInserito=textOpere.getText();
				 try {
					int r=con.aggiornamento(codiceInserito,nomeInserito,cognomeInserito,tipoInserito,opereInserito);//effettuo
					if (r==1) {
						JOptionPane.showMessageDialog(null, "aggiornamento effettuato con successo!");
					} else {
						JOptionPane.showMessageDialog(null, "Attenzione, non e' stato possibile effettuare l'aggiornamento");
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}//passo il parametro da cambiare
			}
		});
		modifica.setBackground(new Color(240, 230, 140));
		modifica.setFont(new Font("Sylfaen", Font.ITALIC, 15));
		modifica.setBounds(213, 245, 89, 23);
		frame.getContentPane().add(modifica);
		
		JLabel lblNewLabel = new JLabel("Codice\r\n");
		lblNewLabel.setFont(new Font("Sylfaen", Font.ITALIC, 14));
		lblNewLabel.setBounds(10, 21, 46, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("nome P");
		lblNewLabel_1.setFont(new Font("Sylfaen", Font.ITALIC, 14));
		lblNewLabel_1.setBounds(10, 66, 46, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Cognome P");
		lblNewLabel_2.setFont(new Font("Sylfaen", Font.ITALIC, 13));
		lblNewLabel_2.setBounds(10, 110, 75, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Tipo");
		lblNewLabel_3.setFont(new Font("Sylfaen", Font.ITALIC, 14));
		lblNewLabel_3.setBounds(10, 153, 46, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Opere");
		lblNewLabel_4.setFont(new Font("Sylfaen", Font.ITALIC, 15));
		lblNewLabel_4.setBounds(10, 193, 46, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		textCodice = new JTextField();
		textCodice.setBounds(82, 10, 137, 30);
		frame.getContentPane().add(textCodice);
		textCodice.setColumns(10);
		
		textNome = new JTextField();
		textNome.setColumns(10);
		textNome.setBounds(82, 51, 137, 30);
		frame.getContentPane().add(textNome);
		
		textCognome = new JTextField();
		textCognome.setColumns(10);
		textCognome.setBounds(82, 92, 137, 30);
		frame.getContentPane().add(textCognome);
		
		textTipo = new JTextField();
		textTipo.setColumns(10);
		textTipo.setBounds(82, 133, 137, 30);
		frame.getContentPane().add(textTipo);
		
		textOpere = new JTextField();
		textOpere.setColumns(10);
		textOpere.setBounds(82, 174, 137, 30);
		frame.getContentPane().add(textOpere);
	}

}
