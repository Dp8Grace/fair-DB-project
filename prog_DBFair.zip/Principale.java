import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.JLabel;

public class Principale {

	private JFrame frame;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principale window = new Principale();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Principale() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBackground(new Color(0, 206, 209));
		frame.setForeground(Color.CYAN);
		frame.setBounds(350, 450, 448, 300);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(64, 224, 208));
		panel.setForeground(Color.WHITE);
		panel.setBounds(0, 0, 432, 361);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton_1 = new JButton("Visualizzazione\r\n");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Visualizzazione finestraVisualizzazione= new Visualizzazione();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();//ci dice cosa e dov'� l'eccezione 
				}
			}
		});
		btnNewButton_1.setFont(new Font("Sylfaen", Font.ITALIC, 16));
		btnNewButton_1.setBackground(new Color(240, 230, 140));
		btnNewButton_1.setBounds(141, 78, 157, 23);
		panel.add(btnNewButton_1);
		 
		JButton nuovo = new JButton("Nuovo");
		nuovo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Inserimento finestraInserimento= new Inserimento();
			}
		});
		nuovo.setFont(new Font("Sylfaen", Font.ITALIC, 16));
		nuovo.setBackground(new Color(240, 230, 140));
		nuovo.setBounds(141, 146, 157, 23);
		panel.add(nuovo);
		
		JButton btnNewButton_3 = new JButton("Modifica");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Modificare finestraModifica= new Modificare();
			}
		});
		btnNewButton_3.setFont(new Font("Sylfaen", Font.ITALIC, 16));
		btnNewButton_3.setBackground(new Color(240, 230, 140));
		btnNewButton_3.setBounds(141, 112, 157, 23);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Elimina");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Elimina finestraElimina= new Elimina();
			}
		});
		btnNewButton_4.setFont(new Font("Sylfaen", Font.ITALIC, 16));
		btnNewButton_3.setFont(new Font("Sylfaen", Font.ITALIC, 16));
		btnNewButton_4.setBackground(new Color(240, 230, 140));
		btnNewButton_4.setBounds(141, 180, 157, 23);
		panel.add(btnNewButton_4);
		
		JTextPane txtpnBenvenutoNellaHome = new JTextPane();
		txtpnBenvenutoNellaHome.setForeground(new Color(0, 0, 0));
		txtpnBenvenutoNellaHome.setBackground(new Color(64, 224, 208));
		txtpnBenvenutoNellaHome.setText("Benvenuto nella home principale.\r\nClicca sull'operazione che desideri eseguire...");
		txtpnBenvenutoNellaHome.setFont(new Font("Sitka Subheading", Font.ITALIC, 13));
		txtpnBenvenutoNellaHome.setBounds(94, 23, 268, 44);
		panel.add(txtpnBenvenutoNellaHome);
		txtpnBenvenutoNellaHome.setEditable(false);
		
}	
}

