import java.sql.*;
public class Connessione { public static void main(String[] args) throws Exception {
//	Connection conn = null;
try {
Class.forName("com.mysql.cj.jdbc.Driver"); // specifica il driver che deve essere caricato
String url = "jdbc:mysql://localhost:3306/fieraVesuviana2022";  
Connection con = DriverManager.getConnection(url,"fieraUser","678!"); //Apertura della connessione
System.out.println("Connesione OK\n");
Statement st = con.createStatement(); // creo l'oggetto interrogazione che viene collegato alla connessione da con
ResultSet rs = st.executeQuery("SELECT codice FROM STAND_MOSTRA");
//executeQuery � invocato da interrogazione e fornisce come parametro il testo delle query
// il risultato produce un oggetto risultato assegnato alla classe ResultSet
while(rs.next()) {	// il metodo next permette di rendere tupla corrente una tupla successiva 			
System.out.println (rs.getString("codice")); //getString passa l'attributo che vogliamo come parametro al metodo
}
con.close();
System.out.println("\nConnessione chiusa");
}// il ciclo restituir� il contenuto di risultato finch� non avremo un valore booleano falso
catch(ClassNotFoundException e) {
System.out.println("Db driver not found\n");
System.out.println(e);
}
catch(Exception e) {// eccezione generata dal sistema in caso di errori
System.out.println("Connessione fallita\n");
System.out.println(e);
} }}

