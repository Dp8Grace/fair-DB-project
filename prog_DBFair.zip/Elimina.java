import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Elimina {

	private JFrame frame;
	private JTextField textCodice;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Elimina window = new Elimina();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Elimina() {
		initialize();
		this.frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(64, 224, 208));
		frame.setBounds(100, 100, 498, 351);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton Elimina = new JButton("Elimina");
		Elimina.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 Operazioni con=new Operazioni();// dichiaro una variabile...un nuovo oggetto di tipo operazione
				String codiceInserito=textCodice.getText();// recupero il codice inserito dall'utente
				 try {
					int r=con.elimina(codiceInserito);//richiamo dalla classe operazioni il metodo elimina
					if (r==1) {
						JOptionPane.showMessageDialog(null, "Eliminazione effettuata con successo!");
					} else {
						JOptionPane.showMessageDialog(null, "Attenzione, non e' stato possibile eliminare");
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}//passo il parametro da eliminare 
			}
		});
		Elimina.setBackground(new Color(240, 230, 140));
		Elimina.setFont(new Font("Sylfaen", Font.ITALIC, 15));
		Elimina.setBounds(213, 245, 89, 23);
		frame.getContentPane().add(Elimina);
		
		textCodice = new JTextField();
		textCodice.setBounds(91, 11, 128, 35);
		frame.getContentPane().add(textCodice);
		textCodice.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Codice\r\n");
		lblNewLabel.setFont(new Font("Sylfaen", Font.ITALIC, 14));
		lblNewLabel.setBounds(10, 21, 46, 14);
		frame.getContentPane().add(lblNewLabel);

	}
}
