
public class STAND_Mostra {
	String codice;
	String nomeP;
	String cognomeP;
	String tipo;
	String opere;
	
	public STAND_Mostra(String codice, String nomeP, String cognomeP, String tipo, String opere) {
		super();
		this.codice = codice;
		this.nomeP = nomeP;
		this.cognomeP = cognomeP;
		this.tipo = tipo;
		this.opere = opere;
	} 
	public STAND_Mostra() {
		this.codice ="";
		this.nomeP = "";
		this.cognomeP = "";
		this.tipo = "";
		this.opere ="";
	}
	public String getCodice() {
		return codice;
	}
	public void setCodice(String codice) {
		this.codice = codice;
	}
	public String getNomeP() {
		return nomeP;
	}
	public void setNomeP(String nomeP) {
		this.nomeP = nomeP;
	}
	public String getCognomeP() {
		return cognomeP;
	}
	public void setCognomeP(String cognomeP) {
		this.cognomeP = cognomeP;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getOpere() {
		return opere;
	}
	public void setOpere(String opere) {
		this.opere = opere;
	}
	//@Override
	public String toString() {
		return "STAND_Mostra [codice=" + codice + ", nomeP=" + nomeP + ", cognomeP=" + cognomeP + ", tipo=" + tipo
				+ ", opere=" + opere + "]";
	} 
	
}