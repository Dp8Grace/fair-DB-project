import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Operazioni {
	private final String URL="jdbc:mysql://localhost:3306/fieraVesuviana2022"; // specifica il driver che deve essere caricato
	private final String USER="root";
	private final String PASS = "Graziaaracawa99!";
	private Connection connessione;
	
	private int inizioConnessione() throws SQLException {
		this.connessione= DriverManager.getConnection(URL, USER, PASS);//carico la stringa di connessione
		if (this.connessione!=null) {
			return 1;
		} else 
		{return -1;}
	}// metodo
	
	private void chiudiConnessione() throws SQLException{
		if (this.connessione!=null) {
		 connessione.close();}// eccezione data da degli errori che chiude l'esecuzione del programma
	}
	
	public int elimina(String codice) throws SQLException {//operazione di eliminazione
		String sql="delete from STAND_MOSTRA where codice='"+codice+"'";
		if (inizioConnessione()!=1) {
			return -1;
		}
		Statement stmt=connessione.createStatement();// creo l'oggetto 
		int result=stmt.executeUpdate(sql); // metodo che rispetto all'operazione di SQL scelta ci restituisce le righe aggiornate
		chiudiConnessione();
		return result;
	}// chiusura elimina
	
	public int inserimento (String codice, String nomeP, String cognomeP, String tipo, String opere) throws SQLException {
		String sql =  "insert into STAND_mostra(codice,nomeP,cognomeP,tipo_Mostra,opere)values('"+ codice +"','"+ nomeP +"','"+ cognomeP +"','"+ tipo +"','"+ opere +"')";
		if (inizioConnessione()!=1) {
			return -1;
		}
		Statement stmt=connessione.createStatement();
		int result=stmt.executeUpdate(sql);//scandisce la tupla corrente da quella succesiva 
		chiudiConnessione();
		return result;
	}// chiusura inserimento
										//passo i parametri
	public int aggiornamento (String codice, String nomeP, String cognomeP, String tipo, String opere) throws SQLException {
		String sql =  "update STAND_Mostra set codice='"+ codice +"',nomeP='"+ nomeP +"',cognomeP='"+ cognomeP +"',tipo_Mostra='"+ tipo +"',opere='"+ opere +"'WHERE codice='"+codice+"'";
		if (inizioConnessione()!=1) {
			return -1;
		}
		Statement stmt=connessione.createStatement(); // istanza per eseguire la query
		int result=stmt.executeUpdate(sql);
		chiudiConnessione();
		return result;
	}// chiusura aggiornamento
	
	public ArrayList<STAND_Mostra> visualizza() throws SQLException{
		ArrayList<STAND_Mostra> stand= new ArrayList<STAND_Mostra>();//dichiaro una nuova lista Sand Mostra
		String sql="Select * From STAND_MOSTRA";
		inizioConnessione();
		Statement stmt=connessione.createStatement();// oggetto di connessione, variabile per le query
		ResultSet result=stmt.executeQuery(sql);
		STAND_Mostra s;
		while (result.next()) {//scorro
			s=new STAND_Mostra();
			s.setCodice(result.getString("codice"));
			s.setNomeP(result.getString("nomeP"));// passa il nome dell'attributo come parametro del metodo
			s.setCognomeP(result.getString("cognomeP"));
			s.setTipo(result.getString("tipo_Mostra"));
			s.setOpere(result.getString("opere"));
			stand.add(s);
		} // chiusura visualizza
		chiudiConnessione();
		return stand;
	}
}


