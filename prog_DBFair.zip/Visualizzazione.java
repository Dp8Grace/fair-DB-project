import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JTextField;
import javax.swing.JLabel;

public class Visualizzazione {

	private JFrame frame;
	private JTextField textNome;
	private JTextField textCodice;
	private JTextField textCognome;
	private JTextField textTipo;
	private JTextField textOpere;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Visualizzazione window = new Visualizzazione();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the application.
	 * @throws SQLException 
	 */
	public Visualizzazione() throws SQLException {
		initialize();
		this.frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws SQLException 
	 */
	private void initialize() throws SQLException {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Sylfaen", Font.ITALIC, 13));
		frame.getContentPane().setBackground(new Color(64, 224, 208));
		frame.setBounds(100, 100, 676, 332);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		ArrayList<STAND_Mostra> listaMostra=new ArrayList<STAND_Mostra>();
		Operazioni con=new Operazioni();//richiamo un nuovo oggetto di tipo operazioni
		listaMostra=con.visualizza();// richiamo il metodo.... per eseguire la query
		
            int count=0;        
            for(STAND_Mostra sm : listaMostra)//scorro la lista di Stand Mostra 
            {
                JLabel label = new JLabel();
                label.setText(""+sm.toString()); // stampo
                label.setBounds(16, count*30, 1000, 10); // posizione
                frame.getContentPane().add(label);  // aggiunta al pannello 

                count++;
            }
            JLabel label = new JLabel("");
            label.setFont(new Font("Sitka Subheading", Font.ITALIC, 14));
            label.setBackground(new Color(64, 224, 208));
            this.frame.getContentPane().add(label);
 
	}
}
